# coding:utf-8

import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt  
from matplotlib.ticker import FuncFormatter
import xlrd
from pandas import Series, DataFrame
from matplotlib.ticker import MultipleLocator
font1 = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 28,
}

font2 = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 28,
}

plt.subplot(1,2,1)
#figure, ax = plt.subplots(figsize=figsize)
ax = plt.gca()

xls_file = pd.ExcelFile('./parablock.xlsx')  
table = xls_file.parse('transpose')                 
table.tail()  

df = table.set_index('item')       
df.tail()     
dlt_1d3p = df['dlt_1d3p']
dlt_1d5p = df['dlt_1d5p']
fd_1d3p =  df['fd_1d3p']
fd_1d5p =  df['fd_1d5p']
dlt_2d5p = df['dlt_2d5p']
dlt_2d9p = df['dlt_2d9p']
fd_2d5p	 = df['fd_2d5p']
fd_2d9p	 = df['fd_2d9p']
dlt_3d7p = df['dlt_3d7p']
dlt_3d27 = df['dlt_3d27p']
fd_3d7p	 = df['fd_3d7p']
fd_3d27p = df['fd_3d27p']
no = df['no']

plt.subplot(1,3,1) 
 
plt.grid(True, which='major',axis="y",color='black', linestyle='--', linewidth=1,alpha=0.3,zorder=-1)
 
ax = plt.gca() 
l1=plt.plot(df['no'],dlt_1d3p, color='#60acfc', marker ='^', linestyle='-',label='Multiple loads',linewidth=3,ms=10)
l2=plt.plot(df['no'],dlt_1d5p, color='#feb64d', marker ='^', linestyle='-',label='Data Reorganization',linewidth=3,ms=10)
l3=plt.plot(df['no'],fd_1d3p , color='#ff7c7c', marker ='o', linestyle='-',       label='DLT',linewidth=3,ms=10)
l4=plt.plot(df['no'],fd_1d5p ,color='#9287e7', marker ='o', linestyle='-',label='Our',linewidth=3,ms=10) 
plt.ylim(0,100)
plt.xticks(no, ()) 
plt.tick_params(labelsize=28)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels] 
#plt.title('The Lasers in Three Conditions') 

 
plt.xlabel('Size',font1)
 
plt.subplot(1,3,2)
#figure, ax = plt.subplots(figsize=figsize)
ax = plt.gca()
plt.grid(True, which='major',axis="y",color='black', linestyle='--', linewidth=1,alpha=0.3,zorder=-1)
l1=plt.plot(df['no'],dlt_2d5p, color='#60acfc', marker ='^', linestyle='-',label='Multiple loads',linewidth=3,ms=10)
l2=plt.plot(df['no'],dlt_2d9p, color='#feb64d', marker ='^', linestyle='-',label='Data Reorganization',linewidth=3,ms=10)
l3=plt.plot(df['no'],fd_2d5p	, color='#ff7c7c', marker ='o', linestyle='-',       label='DLT',linewidth=3,ms=10)
l4=plt.plot(df['no'],fd_2d9p	,color='#9287e7', marker ='o', linestyle='-',label='Our',linewidth=3,ms=10)   
plt.ylim(0,100) 
plt.xticks(no, ()) 
plt.tick_params(labelsize=28)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels] 
#plt.title('The Lasers in Three Conditions') 

 
plt.xlabel('Size',font1)


plt.subplot(1,3,3)
#figure, ax = plt.subplots(figsize=figsize)
ax = plt.gca()
plt.grid(True, which='major',axis="y",color='black', linestyle='--', linewidth=1,alpha=0.3,zorder=-1)
l1=plt.plot(df['no'],dlt_3d7p ,color='#60acfc', marker ='^', linestyle='-',label='Multiple loads',linewidth=3,ms=10)
l2=plt.plot(df['no'],dlt_3d27 , color='#feb64d', marker ='^', linestyle='-',label='Data Reorganization',linewidth=3,ms=10)
l3=plt.plot(df['no'],fd_3d7p	 ,color='#ff7c7c', marker ='o', linestyle='-',       label='DLT',linewidth=3,ms=10)
l4=plt.plot(df['no'],fd_3d27p ,color='#9287e7', marker ='o', linestyle='-',label='Our',linewidth=3,ms=10)   
plt.ylim(0,100) 
plt.xticks(no, ()) 
#plt.xticks(no,  ('$2^0$','$2^2$','$2^4$','$2^6$','$2^8$','$2^{10}$' )) 
plt.tick_params(labelsize=28)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels] 
#plt.title('The Lasers in Three Conditions') 

#plt.ylabel('GFlops/s',font1)
plt.xlabel('Size',font1)


#plt.legend( loc=2,ncol=5,bbox_to_anchor=(-2.5,1.27),prop=font2)
fig = plt.gcf()
fig.set_size_inches(16, 6)
plt.subplots_adjust( left = 0.06,right = 0.98,top = 0.86 , bottom = 0.2)
plt.margins(0,0)
plt.show()
