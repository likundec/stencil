import numpy as np
import matplotlib.pyplot as plt
import numpy as np                           
import pandas as pd
import xlrd
from pandas import Series, DataFrame
from pylab import mpl
from matplotlib.ticker import MultipleLocator
from scipy import interpolate

import brewer2mpl
bmap = brewer2mpl.get_map('set3', 'qualitative', 8)
colors = bmap.mpl_colors
import matplotlib as mpl

fig = plt.figure(figsize=(20,8.5))

xls_file = pd.ExcelFile('./parablock.xlsx')  
table = xls_file.parse('Sheet2')                 
table.tail()  

df = table.set_index('item')       
df.tail()          

plt.subplot(2,4,1)
 
plt.plot(df['no'], df['1d3p_sdsl'],   marker ='>',color='#60acfc', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d3p_pluto'],  marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw') 
plt.plot(df['no'], df['1d3p_ompp'],   marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d3p_our'],    marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d3p_2s'],     marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d3p512_2s'],  marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.xlim(1,36)
plt.ylim(0,250)
#plt.xticks([])
#plt.yticks([])
#marker ='>',color='#60acfc',
#marker ='D',
#marker ='<',
#marker ='o',color='#ff7c7c',
#marker ='s',color='#9287e7',
#marker ='v',color='#5C81C4',
plt.xticks([])
plt.yticks([])
plt.subplot(2,4,2)
 						
plt.plot(df['no'], df['1d5p_sdsl'], marker ='>',color='#60acfc', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d5p_pluto'],marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw') 
plt.plot(df['no'], df['1d5p_ompp'], marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d5p_our'],  marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d5p_2s'],   marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1d5p512_2s'],marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.xlim(1,36)
plt.ylim(0,160)
plt.xticks([])
plt.yticks([])
plt.subplot(2,4,3)

 							
plt.plot(df['no'], df['1dapop_pluto'],  marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw') 
plt.plot(df['no'], df['1dapop_ompp'],   marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1dapop_our'],    marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1dapop_2s'],     marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['1dapop512_2s'],  marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.xlim(1,36)
plt.ylim(0,100)
plt.xticks([])
plt.yticks([])
plt.subplot(2,4,4)
 													
plt.plot(df['no'], df['2d5p_sdsl'],   marker ='>',color='#60acfc', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d5p_pluto'],  marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw') 
plt.plot(df['no'], df['2d5p_ompp'],   marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d5p_our'],    marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d5p_2s'],     marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d5p512_2s'],  marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.xlim(1,36)
plt.ylim(0,60)
plt.xticks([])
plt.yticks([])
plt.subplot(2,4,5)
 																	
plt.plot(df['no'], df['2d9p_sdsl'], marker ='>',color='#60acfc', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d9p_pluto'],marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw') 
plt.plot(df['no'], df['2d9p_ompp'], marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d9p_our'],  marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d9p_2s'],   marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d9p512_2s'],marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.xlim(1,36)
plt.ylim(0,60)
plt.xticks([])
plt.yticks([])



plt.subplot(2,4,6)


#plt.plot(df['no'], df['empty'],  marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw') 
plt.plot(df['no'], df['2d8p_pluto'], marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')	 																					 
plt.plot(df['no'], df['2d8p_ompp'],  marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d8p_our'],   marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d8p_2s'],    marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['2d8p512_2s'], marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.xlim(1,36)
plt.ylim(0,50)
plt.xticks([])
plt.yticks([])


plt.subplot(2,4,7) 																				 
plt.plot(df['no'], df['3d9p_sdsl'],   marker ='>',color='#60acfc', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d9p_pluto'],  marker ='D', color='#32d3eb', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d9p_yask'],  marker ='^',color='#5bc49f',  linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d9p_ompp'],   marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d9p_our'],    marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d9p_2s'],     marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d9p512_2s'],  marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.xlim(1,36)
plt.xticks([])
plt.yticks([])

plt.subplot(2,4,8)
 																													 
plt.plot(df['no'], df['3d27p_sdsl'],  marker ='>',color='#60acfc', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d27p_pluto'], marker ='D', color='#32d3eb', linestyle='-',markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d27p_yask'],  marker ='^',color='#5bc49f',  linestyle='-',markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d27p_ompp'],  marker ='<', color='#feb64d',linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d27p_our'],   marker ='o',color='#ff7c7c', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d27p_2s'],    marker ='s',color='#9287e7', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')
plt.plot(df['no'], df['3d27p512_2s'], marker ='v',color='#5C81C4', linestyle='-', markersize=6,markeredgewidth=0, linewidth=2,label='iiiw')



plt.xlim(1,36)
plt.xticks([])
plt.yticks([]) 
plt.show()
