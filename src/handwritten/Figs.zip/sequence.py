# coding:utf-8

import csv
import numpy as np
import matplotlib.pyplot as plt  
from matplotlib.ticker import FuncFormatter
font1 = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 30,
}

font2 = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 24,
}

plt.subplot(1,2,1)
#figure, ax = plt.subplots(figsize=figsize)
ax = plt.gca()

 
x5=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y5=[6.23,5.74 ,4.97, 3.43 ,3.27 ,3.29 ,1.56 ,1.53 ,1.51 , 0.72 ,0.77 ,0.75 ] 

x9=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y9=[1.93,3.18,3.06, 2.38,2.43,2.25,1.62,1.54,1.51, 0.79,0.77,0.74]
x10=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y10=[3.18,4.1,3.88, 2.8,3.03,2.84,1.64,1.54,1.64, 0.8,0.76,0.76]
x11=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y11=[4.87,5.95,6.12, 4.46,4.41,3.87,2.7,2.41,2.61, 1.31,1.44,1.38] 
x13=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y13=[7.47,7.87,7.75, 6.39,5.93,4.92,4.65,4.15,4.04, 2.0,2.08,2.02] 

plt.xlim(1,13)
plt.ylim(0,9) 

l9= plt.plot(x9,y9,  color='#60acfc', marker ='<', linestyle='-',label='Multiple loads',linewidth=3,ms=10)
l10=plt.plot(x10,y10,color='#32d3eb', marker ='>', linestyle='-',label='Data Reorganization',linewidth=3,ms=10)
l5=plt.plot(x5,y5,   color='#5bc49f', marker ='*', linestyle='-',       label='DLT',linewidth=3,ms=10)
l11=plt.plot(x11,y11,color='#feb64d', marker ='o', linestyle='-',label='Our',linewidth=3,ms=10)
l13=plt.plot(x13,y13,color='#ff7c7c', marker ='s', linestyle='-',label='Our (2 steps)',linewidth=3,ms=10)
#l14=plt.plot(x14,y14,'rs--',label='Transpose-free two-step our',linewidth=3)
plt.plot([0,1],[0,1])

plt.xticks(x5, ('$1\\times10^3$','$2\\times10^3$','$3\\times10^3$', '$2\\times10^4$','$4\\times10^4$','$8\\times10^4$','$1.6\\times10^5$','$3.2\\times10^5$','$6.4\\times10^5$','$5.12\\times10^6$','$1.02\\times10^7$', '$2.04\\times10^7$')) 
plt.tick_params(labelsize=24)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels] 
plt.xticks(rotation=30)
plt.ylabel('GFlops/s',font1)
plt.xlabel('Size',font1)
 
plt.subplot(1,2,2)
#figure, ax = plt.subplots(figsize=figsize)
ax = plt.gca()
 
x5=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y5=[6.02,5.63,4.61,4.3,4.26,4.15,3.91,3.56,2.29,1.48,1.47,1.15  ] 

x9=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y9=[2.34,2.53,2.62,2.43,2.21,2.11,1.65,1.54,1.52,0.65,0.62,0.54]
x10=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y10=[3.87,3.65,3.92,3.21,3.12,2.88,2.54,2.32,2.11,0.78,0.77,0.75]
x11=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y11=[5.85,5.93,5.82,5.15,5.07,4.89,4.11,3.54,3.28,1.85,1.67,1.58] 
x13=[1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5]
y13=[7.56,7.58,7.61,6.42,6.25,5.87,5.26,5.11,4.77,2.2,2.11,2.07] 
plt.xlim(1,13)
plt.ylim(0,9)

 

l9= plt.plot(x9,y9,  color='#60acfc', marker ='<', linestyle='-',label='Multiple loads',linewidth=3,ms=10)
l10=plt.plot(x10,y10,color='#32d3eb', marker ='>', linestyle='-',label='Data Reorganization',linewidth=3,ms=10)
l5=plt.plot(x5,y5,   color='#5bc49f', marker ='*', linestyle='-',label='DLT',linewidth=3,ms=10)
l11=plt.plot(x11,y11,color='#feb64d', marker ='o', linestyle='-',label='Our',linewidth=3,ms=10)
l13=plt.plot(x13,y13,color='#ff7c7c', marker ='s', linestyle='-',label='Our (2 steps)',linewidth=3,ms=10) 
#l14=plt.plot(x14,y14,'rs--',label='Transpose-free two-step our',linewidth=3)
plt.plot([0,1],[0,2])
 
plt.xticks(x5, ('$1\\times10^3$','$2\\times10^3$','$3\\times10^3$','$8\\times10^3$','$1.6\\times10^4$','$3.2\\times10^4$','$2.56\\times10^5$','$5.12\\times10^5$','$1.02\\times10^6$','$5.12\\times10^6$','$1.02\\times10^7$', '$2.04\\times10^7$' )) 
plt.tick_params(labelsize=22)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels] 
#plt.title('The Lasers in Three Conditions') 
plt.xticks(rotation=30)
plt.ylabel('GFlops/s',font1)
plt.xlabel('Size',font1)
#plt.legend( loc=1,ncol=2,prop=font2)
plt.legend( loc=2,ncol=5,bbox_to_anchor=(-1.28,1.27),prop=font2)
fig = plt.gcf()
fig.set_size_inches(16, 6)
plt.subplots_adjust( left = 0.06,right = 0.96,top = 0.86 , bottom = 0.24)
plt.margins(0,0)
plt.show()
