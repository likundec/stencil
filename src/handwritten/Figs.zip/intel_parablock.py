import numpy as np
import matplotlib.pyplot as plt
import numpy as np                           
import pandas as pd
import xlrd
from pandas import Series, DataFrame
from pylab import mpl
from matplotlib.ticker import MultipleLocator
fig = plt.figure(figsize=(20,3.5))

name_list = ['1D-Heat', '1D5P','APOP', '2D-Heat', '2D9P', 'Game of Life', '3D-Heat','3D27P']

size = 8
x = np.arange(size)
total_width, n = 0.8, 6
width = total_width / n
width_p = width/2

xls_file = pd.ExcelFile('./parablock.xlsx')  
table = xls_file.parse('Sheet1')                 
table.tail()  

df = table.set_index('item')       
df.tail()          



sdsl = df['sdsl']
pluto = df['pluto']
ompp =  df['ompp']
yask =  df['yask']
our =   df['our']
our2s = df['2s']
x = list(range(len(sdsl))) 
y = list(range(len(sdsl))) 
for i in range(len(y)):
    y[i] = y[i] + width_p
ax1 = fig.add_subplot(111) 
ax2 = ax1.twinx()
ax2.set_ylim(0, 6)

y_major_locator=MultipleLocator(40)
ax1.yaxis.set_major_locator(y_major_locator)
ax1.set_ylim(0, 240) 
 
ax1.grid(True, which='major',axis="y",color='black', linestyle='--', linewidth=1,alpha=0.3,zorder=-1)
ax1.set_axisbelow(True)

ax1.bar(x, sdsl, width=width, label='boy',color='#60acfc',alpha=0.8 )
ax2.plot(y, df['sdsls'],             'r^',  markersize=8, label='iiiw')
for i in range(len(x)):
    x[i] = x[i] + width
    y[i] = y[i] + width
ax1.bar(x, pluto, width=width, label='girl',color='#32d3eb', alpha=0.8) 
ax2.plot(y, df['plutos'],             'r^',  markersize=8, label='iiiw')
for i in range(len(x)):
    x[i] = x[i] + width
    y[i] = y[i] + width
ax1.bar(x, ompp, width=width, label='girl',color='#feb64d', alpha=0.8) 
ax2.plot(y, df['ompps'],             'r^',  markersize=8, label='iiiw')
for i in range(6,8):
    x[i] = x[i] + width
    y[i] = y[i] + width
ax1.bar(x, yask, width=width, label='boy',color='#5bc49f',  alpha=0.8)
ax2.plot(y, df['yasks'],             'r^',  markersize=8, label='iiiw')

for i in range(len(x)):
    x[i] = x[i] + width
    y[i] = y[i] + width
ax1.bar(x, our, width=width, label='girl',color='#ff7c7c',alpha=0.8 ) 
ax1.bar(x , df['our512'], bottom= df['our'], color='#ff7c7c',width=width, hatch='///',label='Our(AVX-512)')
ax2.plot(y, df['ours'],             'r^',  markersize=8, label='iiiw')
ax2.plot(y, df['our512s'], 'b*',markersize=10,label='iiiw')
for i in range(len(x)):
    x[i] = x[i] + width
    y[i] = y[i] + width
ax1.bar(x, our2s, width=width, label='girl',color='#9287e7',alpha=0.8 ) 
ax1.bar(x, df['2s512'], bottom= df['2s'], color='#9287e7',width=width, hatch='///'  ,label='Our(AVX-512,2 steps)')
ax2.plot(y, df['2ss'],             'r^',  markersize=8, label='iiiw')
ax2.plot(y, df['2s512s'],  'b*',markersize=10,label='iiiw')
 
plt.xticks([])
ax1.tick_params(labelsize=16)
ax2.tick_params(labelsize=16)
labels = ax1.get_xticklabels() + ax1.get_yticklabels() + ax2.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]
#ax1.legend( loc=3,ncol=3)
plt.show()
